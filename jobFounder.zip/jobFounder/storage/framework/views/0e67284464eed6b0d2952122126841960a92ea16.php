
    <?php $__env->startSection('main'); ?>

    <main class="container d-flex justify-content-center" style="min-height: 100vh;">
        <div id="accordion" style="width: 800px;">
            <div class="formHeading text-center">
                <h3 >Notifications</h3>
            </div>
            <!-- heading -->
            <p><button type="button" class="btn btn-outline-dark ">mark all as seen</button></p>

            <div class="card-body">
                <ul class="list-group list-group-flush">
                  <?php $__currentLoopData = $user_notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item">
                        <a href="company_dashboard.html">
                        <div class="d-flex justify-content-between">
                            <p><?php echo e($notification->notification); ?></p>
                            <p class="companiesCompanyRole align-bottom"><?php echo e($notification->created_at); ?></p>
                        </div>
                        </a>
                    </li>                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  
                </ul>
            </div>
        </div>
      <!-- main row -->
    </main>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\websites\jobFounder\jobFounder\resources\views/user_notification.blade.php ENDPATH**/ ?>