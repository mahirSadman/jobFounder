
<?php $__env->startSection('main'); ?>
    <main class="container d-flex justify-content-center" style="min-height: 100vh;">
        <div id="accordion" style="width: 600px;">
            <div class="formHeading text-center">
                <h3 >Post a job</h3>
                <p><?php echo e($company->company_name); ?></p>
            </div>
            <!-- heading -->
          <form action="<?php echo e(route('post_jobcreate.store')); ?>" method="POST">
              <?php echo csrf_field(); ?>
            <div >
                <div class="card-body">
                <input type="hidden" id="custId" name="company_id" value="<?php echo e($company->id); ?>">
                    <div class="form-group">
                        <label for="job_title">Job Title</label>
                        <input type="text" class="form-control" id="job_title" name="job_title" >
                        <?php $__errorArgs = ['job_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="description">Description</label>
                        <input type="text" class="form-control" id="description" name="description" >
                        <label for="vacancy">Vacancy</label>
                        <input type="number" class="form-control" id="vacancy" name="vacancy" >
                        <?php $__errorArgs = ['vacancy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <label for="Skills">Skills</label>
                        <input type="text" class="form-control" id="Skills" name="Skills" >
                        <label for="deadline_date">Deadline Date</label>
                        <input type="date" class="form-control" id="deadline_date" name="deadline_date" >
                        <?php $__errorArgs = ['deadline_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                      <div class="form-group">
                      <label for="job_type">Type</label>
                      <select class="form-control" id="job_type" name="job_type" >
                        <option value="FullTime">Full time</option>
                        <option value="PartTime">Part time</option>
                        <option value="Freelancing">Freelancing</option>
                        <option value="Government">Government</option>
                        <option value="Business">Business</option>
                      </select>
                      <?php $__errorArgs = ['job_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <label for="job_category">Category</label>
                      <select class="form-control" id="job_category" name="job_category">
                        <option value="WebDesigning">Web designing</option>
                        <option value="SoftwareDevelopment">Software development</option>
                        <option value="Accountant">Accountant</option>
                        <option value="IT">IT</option>
                        <option value="Receiptionist">Receiptionist</option>
                        <option value="Guard">Guard</option>
                        <option value="Driver">Driver</option>
                        <option value="Teacher">Teacher</option>
                      </select>
                      <?php $__errorArgs = ['job_category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span class="text-danger"><?php echo e($message); ?></span>
                          <br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <div>
            </div>
            <!--  collapseList -->
            <br><br>
            <button type="submit" class="btn btn-primary btn-block" >Create</button>
          </form>

        </div>
      <!-- main row -->
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\websites\jobFounder\jobFounder\resources\views/post_job_create.blade.php ENDPATH**/ ?>